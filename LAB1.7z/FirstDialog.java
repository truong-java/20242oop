import javax.swing.JOptionPane;
public class FirstDialog{
    public static void main(String[] args){
        JOptionPane.showMessageDialog(null, "Hello world! How are you?"); 
        System.exit(0);              
    }
}